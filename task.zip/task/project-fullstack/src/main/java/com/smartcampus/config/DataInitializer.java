package com.smartcampus.config;

import com.smartcampus.model.Event;
import com.smartcampus.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private EventService eventService;

    @Autowired
    private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) throws Exception {
        try {
            jdbcTemplate.execute("ALTER TABLE events MODIFY COLUMN image_url TEXT");
            System.out.println("Successfully altered image_url column to TEXT");
        } catch (Exception e) {
            System.out.println("Could not alter image_url column: " + e.getMessage());
        }

        if (eventService.getAllEvents().isEmpty()) {
            System.out.println("No events found. Seeding default events...");

            Event event1 = new Event();
            event1.setTitle("Future of AI Conference 2026");
            event1.setDescription("Join industry leaders to discuss the next wave of Artificial Intelligence, including generative models and ethical AI.");
            event1.setDepartment("Computer Science");
            event1.setEventType("Conference");
            event1.setDate(LocalDate.now().plusDays(15));
            event1.setTime(LocalTime.of(9, 30));
            event1.setLocation("Main Auditorium");
            event1.setParticipationType("Individual");
            event1.setFeeAmount(15.00);
            event1.setTotalOpenings(200);
            event1.setImageUrl("https://images.unsplash.com/photo-1591453089816-0fbb971b454c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event1);

            Event event2 = new Event();
            event2.setTitle("UX/UI Design Masterclass");
            event2.setDescription("A hands-on workshop focused on creating intuitive user experiences and stunning interfaces using modern design tools.");
            event2.setDepartment("Design");
            event2.setEventType("Workshop");
            event2.setDate(LocalDate.now().plusDays(20));
            event2.setTime(LocalTime.of(14, 0));
            event2.setLocation("Design Lab 3");
            event2.setParticipationType("Individual");
            event2.setFeeAmount(0.00);
            event2.setTotalOpenings(50);
            event2.setImageUrl("https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event2);

            Event event3 = new Event();
            event3.setTitle("Annual Hackathon: Smart Campus Solutions");
            event3.setDescription("Build innovative solutions to improve campus life. 24 hours of coding, networking, and free food!");
            event3.setDepartment("Computer Science");
            event3.setEventType("Hackathon");
            event3.setDate(LocalDate.now().plusDays(30));
            event3.setTime(LocalTime.of(18, 0));
            event3.setLocation("Student Center");
            event3.setParticipationType("Team");
            event3.setFeeAmount(10.00);
            event3.setTotalOpenings(100);
            event3.setImageUrl("https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event3);
        }
        
        if (eventService.getAllEvents().size() <= 3) {
            System.out.println("Seeding additional events for the dashboard...");

            Event event4 = new Event();
            event4.setTitle("Cybersecurity Fundamentals Workshop");
            event4.setDescription("Learn the basics of network security, ethical hacking, and how to protect systems from modern cyber threats.");
            event4.setDepartment("Information Technology");
            event4.setEventType("Workshop");
            event4.setDate(LocalDate.now().plusDays(5));
            event4.setTime(LocalTime.of(10, 0));
            event4.setLocation("Lab 402");
            event4.setParticipationType("Individual");
            event4.setFeeAmount(0.00);
            event4.setTotalOpenings(40);
            event4.setImageUrl("https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event4);

            Event event5 = new Event();
            event5.setTitle("Startup Pitch Competition");
            event5.setDescription("Watch student entrepreneurs pitch their business ideas to a panel of local investors and industry experts.");
            event5.setDepartment("Business");
            event5.setEventType("Seminar");
            event5.setDate(LocalDate.now().plusDays(12));
            event5.setTime(LocalTime.of(16, 30));
            event5.setLocation("Business School Auditorium");
            event5.setParticipationType("Team");
            event5.setFeeAmount(5.00);
            event5.setTotalOpenings(150);
            event5.setImageUrl("https://images.unsplash.com/photo-1475503572774-15a45e5d60b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event5);

            Event event6 = new Event();
            event6.setTitle("Campus Music Festival 2026");
            event6.setDescription("An evening of live performances featuring the best student bands and guest artists. Food trucks will be available!");
            event6.setDepartment("Arts & Culture");
            event6.setEventType("Social");
            event6.setDate(LocalDate.now().plusDays(25));
            event6.setTime(LocalTime.of(19, 0));
            event6.setLocation("Campus Main Lawn");
            event6.setParticipationType("Individual");
            event6.setFeeAmount(20.00);
            event6.setTotalOpenings(500);
            event6.setImageUrl("https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80");
            eventService.saveEvent(event6);
            
            System.out.println("Additional events seeded successfully.");
        }
    }
}
